### go-simplejson

a Go package to interact with arbitrary JSON

[![Build Status](https://secure.travis-ci.org/bitly/go-simplejson.png)](http://travis-ci.org/bitly/go-simplejson)

### Importing

    import github.com/bitly/go-simplejson

### Documentation

Visit the docs on [gopkgdoc](http://godoc.org/github.com/bitly/go-simplejson)
